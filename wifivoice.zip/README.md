# WiFi音声通話 (SH-02D / Android 2.3.5 向け)

SIP(android.net.sip)を使わず、UDPで生PCM音声を相手端末へ直接送る1対1通話アプリです。

## 使い方
1. 2台とも同じWi-Fiに接続する
2. 画面上部(タイトルバー)に表示される「自分のIP」を相手に伝える
3. 両方の端末で、相手のIPアドレスを入力して「通話開始」を押す
4. 終了は「切断」

## 仕様
- UDPポート: 50005 (送受信とも同じポート)
- 音声: 8kHz / モノラル / 16bit PCM (非圧縮)、20ms(320バイト)ごとに1パケット
- 帯域: 約128kbps
- 受話はイヤホン/受話口から出ます (STREAM_VOICE_CALL)。エコー対策なしのため、
  スピーカーにするとハウリングします。ヘッドセット推奨。
- 暗号化・認証なし。信頼できるLAN内でのみ使用してください。
- 端末の「APアイソレーション」(Wi-Fi端末間通信の遮断)が有効なルーターでは通話できません。

## ビルド (PCなし / GitHub Actions)
1. このZIPの中身をそのままリポジトリのルートにアップロード(`.github/workflows/build.yml` がルートにあること)
2. push すると Actions が走る。完了後、Artifacts の `wifivoice-debug-apk` から APK を取得
3. SH-02D で提供元不明アプリの許可をONにしてインストール

構成: Gradle 7.6.4 / Android Gradle Plugin 7.4.2 / JDK 11 / compileSdk 33 / minSdk 10 / Java 1.7
