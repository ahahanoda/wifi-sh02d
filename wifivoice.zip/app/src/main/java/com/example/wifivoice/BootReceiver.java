package com.example.wifivoice;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** 端末の起動時に待受サービスを自動で開始する */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        context.startService(new Intent(context, CallService.class));
    }
}
