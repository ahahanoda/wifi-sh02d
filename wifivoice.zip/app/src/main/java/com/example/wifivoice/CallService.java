package com.example.wifivoice;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketTimeoutException;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.media.RingtoneManager;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.Process;
import android.os.SystemClock;
import android.os.Vibrator;
import android.widget.Toast;

/**
 * 待受(着信受付)・呼び出し制御・音声送受信をまとめた常駐サービス。
 * UDPポート50005を1つだけ使い、先頭2バイト [MAGIC][種別] で制御/音声を区別する。
 *
 * 状態遷移の処理(state等)はすべてメインスレッドで行う。
 * ネットワーク送信もメインスレッドから行うが、targetSdkVersion 10 のため
 * StrictMode(NetworkOnMainThread)の対象外であり、UDPの小パケット送信なので問題ない。
 */
public class CallService extends Service {

    public static final int IDLE = 0;
    public static final int CALLING = 1;   // 発信中
    public static final int RINGING = 2;   // 着信中
    public static final int IN_CALL = 3;   // 通話中

    public interface Listener {
        /** メインスレッドから呼ばれる */
        void onStateChanged();
    }

    public class LocalBinder extends Binder {
        public CallService getService() {
            return CallService.this;
        }
    }

    static final int PORT = 50005;

    private static final byte MAGIC = 0x57;
    private static final int T_VOICE = 0x01;
    private static final int T_INVITE = 0x10;
    private static final int T_RINGING = 0x11;
    private static final int T_ACCEPT = 0x12;
    private static final int T_REJECT = 0x13;
    private static final int T_BYE = 0x14;
    private static final int T_BUSY = 0x15;

    private static final int SAMPLE_RATE = 8000;
    private static final int FRAME_BYTES = 320; // 20ms
    private static final int HEADER = 2;

    private static final long CALL_TIMEOUT = 30000;  // 発信してから応答なし
    private static final long RING_TIMEOUT = 5000;   // 着信中にINVITEが途絶えたら不在着信
    private static final long VOICE_TIMEOUT = 8000;  // 通話中に音声が途絶えたら切断

    private final LocalBinder binder = new LocalBinder();
    private final Handler handler = new Handler();
    private Listener listener;

    // --- 状態 (メインスレッドのみ更新) ---
    private int state = IDLE;
    private volatile InetAddress peer;
    private boolean remoteRinging;
    private long callStart;
    private long lastInvite;
    private long connectedAt;
    private volatile long lastVoice;

    // --- ネットワーク ---
    private DatagramSocket socket;
    private volatile boolean alive;
    private Thread recvThread;

    // --- 音声 ---
    private final Object audioLock = new Object();
    private volatile boolean audioOn;
    private AudioRecord recorder;
    private AudioTrack track;
    private Thread sendThread;

    // --- その他 ---
    private WifiManager.WifiLock wifiLock;
    private PowerManager.WakeLock cpuLock;
    private MediaPlayer ringPlayer;
    private Vibrator vibrator;

    // ------------------------------------------------------------------
    // Service lifecycle
    // ------------------------------------------------------------------

    @Override
    public void onCreate() {
        super.onCreate();

        // 待受中もWi-Fiが眠らないようにする(電池は多めに消費する)
        WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        if (wm != null) {
            wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL, "wifivoice");
            wifiLock.setReferenceCounted(false);
            wifiLock.acquire();
        }

        try {
            socket = new DatagramSocket(null);
            socket.setReuseAddress(true);
            socket.bind(new InetSocketAddress(PORT));
            socket.setSoTimeout(1000);
        } catch (IOException e) {
            toast("待受を開始できません: " + e.getMessage());
            socket = null;
            stopSelf();
            return;
        }

        alive = true;
        recvThread = new Thread(new Runnable() {
            public void run() {
                recvLoop();
            }
        }, "wifivoice-recv");
        recvThread.start();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    @Override
    public void onDestroy() {
        hangUp();
        alive = false;
        if (socket != null) {
            socket.close();
        }
        if (recvThread != null) {
            try {
                recvThread.join(1500);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        handler.removeCallbacksAndMessages(null);
        if (wifiLock != null && wifiLock.isHeld()) {
            wifiLock.release();
        }
        super.onDestroy();
    }

    // ------------------------------------------------------------------
    // UIから呼ぶAPI (メインスレッド)
    // ------------------------------------------------------------------

    public void setListener(Listener l) {
        listener = l;
    }

    public int getState() {
        return state;
    }

    public String getPeerAddress() {
        InetAddress p = peer;
        return p == null ? "" : p.getHostAddress();
    }

    public boolean isRemoteRinging() {
        return remoteRinging;
    }

    public long getConnectedAt() {
        return connectedAt;
    }

    /** 発信 */
    public void call(String ip) {
        if (state != IDLE) {
            return;
        }
        InetAddress addr;
        try {
            addr = InetAddress.getByName(ip);
        } catch (IOException e) {
            toast("相手のIPアドレスが不正です");
            return;
        }
        if (!sendTo(addr, T_INVITE)) {
            toast("送信できません。Wi-Fi接続を確認してください");
            return;
        }
        peer = addr;
        remoteRinging = false;
        callStart = SystemClock.elapsedRealtime();
        setState(CALLING);
        ensureTick();
    }

    /** 着信に応答 */
    public void accept() {
        if (state != RINGING) {
            return;
        }
        stopRinging();
        sendTo(peer, T_ACCEPT);
        if (!enterCall()) {
            sendBurst(peer, T_BYE);
            endCall("マイクを使用できません");
        }
    }

    /** 状況に応じて 発信取消 / 着信拒否 / 通話切断 */
    public void hangUp() {
        switch (state) {
            case CALLING:
            case IN_CALL:
                sendBurst(peer, T_BYE);
                break;
            case RINGING:
                sendBurst(peer, T_REJECT);
                break;
            default:
                return;
        }
        endCall(null);
    }

    // ------------------------------------------------------------------
    // 状態管理 (メインスレッド)
    // ------------------------------------------------------------------

    private void setState(int s) {
        state = s;
        if (listener != null) {
            listener.onStateChanged();
        }
    }

    private boolean enterCall() {
        if (!startAudio()) {
            return false;
        }
        connectedAt = SystemClock.elapsedRealtime();
        lastVoice = connectedAt;
        remoteRinging = false;
        if (cpuLock == null) {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            cpuLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "wifivoice-call");
            cpuLock.setReferenceCounted(false);
        }
        if (!cpuLock.isHeld()) {
            cpuLock.acquire();
        }
        setState(IN_CALL);
        ensureTick();
        return true;
    }

    private void endCall(String message) {
        handler.removeCallbacks(tick);
        stopRinging();
        stopAudio();
        if (cpuLock != null && cpuLock.isHeld()) {
            cpuLock.release();
        }
        peer = null;
        remoteRinging = false;
        setState(IDLE);
        if (message != null) {
            toast(message);
        }
    }

    private void ensureTick() {
        handler.removeCallbacks(tick);
        handler.postDelayed(tick, 1000);
    }

    /** 1秒ごとの見張り: INVITE再送 / 応答なし / 不在着信 / 通話途切れ */
    private final Runnable tick = new Runnable() {
        public void run() {
            long now = SystemClock.elapsedRealtime();
            if (state == CALLING) {
                if (now - callStart > CALL_TIMEOUT) {
                    sendBurst(peer, T_BYE);
                    endCall("応答がありません");
                    return;
                }
                sendTo(peer, T_INVITE); // UDPなので再送して取りこぼしを防ぐ
            } else if (state == RINGING) {
                if (now - lastInvite > RING_TIMEOUT) {
                    endCall("不在着信: " + getPeerAddress());
                    return;
                }
            } else if (state == IN_CALL) {
                if (now - lastVoice > VOICE_TIMEOUT) {
                    sendBurst(peer, T_BYE);
                    endCall("通信が途切れました");
                    return;
                }
            }
            if (state != IDLE) {
                handler.postDelayed(this, 1000);
            }
        }
    };

    /** 受信した制御パケットの処理 */
    private void onControl(int type, InetAddress from) {
        switch (type) {
            case T_INVITE:
                handleInvite(from);
                break;
            case T_RINGING:
                if (state == CALLING && from.equals(peer)) {
                    remoteRinging = true;
                    setState(CALLING);
                }
                break;
            case T_ACCEPT:
                if (state == CALLING && from.equals(peer)) {
                    if (!enterCall()) {
                        sendBurst(peer, T_BYE);
                        endCall("マイクを使用できません");
                    }
                }
                break;
            case T_REJECT:
                if (state == CALLING && from.equals(peer)) {
                    endCall("相手が通話を拒否しました");
                }
                break;
            case T_BUSY:
                if (state == CALLING && from.equals(peer)) {
                    endCall("相手は通話中です");
                }
                break;
            case T_BYE:
                if (from.equals(peer)) {
                    if (state == IN_CALL) {
                        endCall("通話が終了しました");
                    } else if (state == RINGING) {
                        endCall("不在着信: " + from.getHostAddress());
                    }
                }
                break;
            default:
                break;
        }
    }

    private void handleInvite(InetAddress from) {
        long now = SystemClock.elapsedRealtime();
        if (state == IDLE) {
            peer = from;
            lastInvite = now;
            sendTo(from, T_RINGING);
            setState(RINGING);
            startRinging();
            wakeScreen();
            launchUi();
            ensureTick();
        } else if (from.equals(peer)) {
            if (state == RINGING) {
                lastInvite = now;
                sendTo(from, T_RINGING);
            } else if (state == IN_CALL) {
                sendTo(from, T_ACCEPT); // ACCEPTが届いていなかった場合の再送
            } else if (state == CALLING) {
                // お互いに同時に発信した場合はそのままつなぐ
                sendTo(from, T_ACCEPT);
                if (!enterCall()) {
                    sendBurst(peer, T_BYE);
                    endCall("マイクを使用できません");
                }
            }
        } else {
            sendTo(from, T_BUSY);
        }
    }

    // ------------------------------------------------------------------
    // 着信の演出 (着信音・バイブ・画面点灯・画面表示)
    // ------------------------------------------------------------------

    private void startRinging() {
        AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        int mode = am.getRingerMode();
        if (mode == AudioManager.RINGER_MODE_NORMAL) {
            try {
                Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
                ringPlayer = new MediaPlayer();
                ringPlayer.setDataSource(this, uri);
                ringPlayer.setAudioStreamType(AudioManager.STREAM_RING);
                ringPlayer.setLooping(true);
                ringPlayer.prepare();
                ringPlayer.start();
            } catch (Exception e) {
                releaseRingPlayer();
            }
        }
        if (mode != AudioManager.RINGER_MODE_SILENT) {
            vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (vibrator != null) {
                vibrator.vibrate(new long[] { 0, 800, 800 }, 0);
            }
        }
    }

    private void stopRinging() {
        releaseRingPlayer();
        if (vibrator != null) {
            vibrator.cancel();
            vibrator = null;
        }
    }

    private void releaseRingPlayer() {
        if (ringPlayer != null) {
            try {
                ringPlayer.stop();
            } catch (Exception e) {
                // ignore
            }
            ringPlayer.release();
            ringPlayer = null;
        }
    }

    @SuppressWarnings("deprecation")
    private void wakeScreen() {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            PowerManager.WakeLock wl = pm.newWakeLock(PowerManager.FULL_WAKE_LOCK
                    | PowerManager.ACQUIRE_CAUSES_WAKEUP
                    | PowerManager.ON_AFTER_RELEASE, "wifivoice-incoming");
            wl.acquire(10000);
        } catch (RuntimeException e) {
            // ignore
        }
    }

    private void launchUi() {
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(i);
    }

    private void toast(String msg) {
        Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_LONG).show();
    }

    // ------------------------------------------------------------------
    // ネットワーク
    // ------------------------------------------------------------------

    private boolean sendTo(InetAddress to, int type) {
        DatagramSocket s = socket;
        if (s == null || to == null) {
            return false;
        }
        byte[] b = new byte[] { MAGIC, (byte) type };
        try {
            s.send(new DatagramPacket(b, b.length, to, PORT));
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    /** 切断系は取りこぼし対策で3回送る */
    private void sendBurst(InetAddress to, int type) {
        for (int i = 0; i < 3; i++) {
            sendTo(to, type);
        }
    }

    private void recvLoop() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO);
        final DatagramSocket s = socket;
        byte[] buf = new byte[1024];
        DatagramPacket p = new DatagramPacket(buf, buf.length);
        while (alive) {
            try {
                p.setLength(buf.length);
                s.receive(p);
            } catch (SocketTimeoutException e) {
                continue;
            } catch (IOException e) {
                if (s.isClosed()) {
                    break;
                }
                try {
                    Thread.sleep(200);
                } catch (InterruptedException ie) {
                    break;
                }
                continue;
            }
            int len = p.getLength();
            if (len < HEADER || buf[0] != MAGIC) {
                continue;
            }
            final int type = buf[1];
            final InetAddress from = p.getAddress();
            if (type == T_VOICE) {
                if (audioOn && from.equals(peer)) {
                    lastVoice = SystemClock.elapsedRealtime();
                    int n = (len - HEADER) & ~1;
                    synchronized (audioLock) {
                        AudioTrack t = track;
                        if (t != null && n > 0) {
                            try {
                                t.write(buf, HEADER, n);
                            } catch (RuntimeException e) {
                                // 停止処理と競合した場合は無視
                            }
                        }
                    }
                }
            } else {
                handler.post(new Runnable() {
                    public void run() {
                        onControl(type, from);
                    }
                });
            }
        }
    }

    // ------------------------------------------------------------------
    // 音声 (8kHz / モノラル / 16bit。バッファは最小限)
    // ------------------------------------------------------------------

    private boolean startAudio() {
        try {
            int recMin = AudioRecord.getMinBufferSize(SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            int trMin = AudioTrack.getMinBufferSize(SAMPLE_RATE,
                    AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
            if (recMin <= 0 || trMin <= 0) {
                return false;
            }
            int recBuf = Math.max(recMin, FRAME_BYTES * 2);
            AudioRecord rec = createRecorder(MediaRecorder.AudioSource.MIC, recBuf);
            if (rec == null) {
                rec = createRecorder(MediaRecorder.AudioSource.VOICE_COMMUNICATION, recBuf);
            }
            if (rec == null) {
                return false;
            }
            AudioTrack tr = new AudioTrack(AudioManager.STREAM_VOICE_CALL, SAMPLE_RATE,
                    AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    Math.max(trMin, FRAME_BYTES * 4), AudioTrack.MODE_STREAM);
            if (tr.getState() != AudioTrack.STATE_INITIALIZED) {
                rec.release();
                tr.release();
                return false;
            }
            recorder = rec;
            synchronized (audioLock) {
                track = tr;
            }
            tr.play();
            audioOn = true;

            final AudioRecord r = rec;
            sendThread = new Thread(new Runnable() {
                public void run() {
                    sendLoop(r);
                }
            }, "wifivoice-send");
            sendThread.start();
            return true;
        } catch (RuntimeException e) {
            stopAudio();
            return false;
        }
    }

    private AudioRecord createRecorder(int source, int bufSize) {
        try {
            AudioRecord r = new AudioRecord(source, SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufSize);
            if (r.getState() == AudioRecord.STATE_INITIALIZED) {
                return r;
            }
            r.release();
        } catch (RuntimeException e) {
            // 次の候補へ
        }
        return null;
    }

    private void stopAudio() {
        audioOn = false;
        if (sendThread != null) {
            try {
                sendThread.join(1500);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            sendThread = null;
        }
        if (recorder != null) {
            try {
                if (recorder.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) {
                    recorder.stop();
                }
            } catch (RuntimeException e) {
                // ignore
            }
            recorder.release();
            recorder = null;
        }
        synchronized (audioLock) {
            if (track != null) {
                try {
                    track.stop();
                } catch (RuntimeException e) {
                    // ignore
                }
                track.release();
                track = null;
            }
        }
    }

    /** マイク → UDP送信 */
    private void sendLoop(AudioRecord rec) {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO);
        final DatagramSocket s = socket;
        byte[] buf = new byte[HEADER + FRAME_BYTES];
        buf[0] = MAGIC;
        buf[1] = (byte) T_VOICE;
        try {
            rec.startRecording();
            while (audioOn) {
                int filled = 0;
                while (audioOn && filled < FRAME_BYTES) {
                    int n = rec.read(buf, HEADER + filled, FRAME_BYTES - filled);
                    if (n < 0) {
                        return;
                    }
                    filled += n;
                }
                InetAddress to = peer;
                if (!audioOn || to == null) {
                    break;
                }
                try {
                    s.send(new DatagramPacket(buf, buf.length, to, PORT));
                } catch (IOException e) {
                    // 一時的な送信失敗は無視 (途切れが続けば見張りが切断する)
                }
            }
        } catch (RuntimeException e) {
            // 録音停止との競合
        }
    }
}
