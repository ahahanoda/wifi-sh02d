package com.example.wifivoice;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity implements View.OnClickListener {

    private static final String PREFS = "wifivoice";
    private static final String KEY_IP = "peer_ip";
    private static final Pattern IPV4 =
            Pattern.compile("^(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})$");

    private EditText ipEdit;
    private Button callButton;
    private VoiceEngine engine;
    private WifiManager wifi;
    private WifiManager.WifiLock wifiLock;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        setVolumeControlStream(AudioManager.STREAM_VOICE_CALL);

        ipEdit = (EditText) findViewById(R.id.edit_ip);
        callButton = (Button) findViewById(R.id.btn_call);
        callButton.setOnClickListener(this);

        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        ipEdit.setText(prefs.getString(KEY_IP, ""));

        wifi = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);

        engine = new VoiceEngine(new VoiceEngine.ErrorListener() {
            public void onError(final String message) {
                runOnUiThread(new Runnable() {
                    public void run() {
                        Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
                        stopCall();
                    }
                });
            }
        });

        showOwnIp();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!engine.isRunning()) {
            showOwnIp();
        }
    }

    @Override
    protected void onDestroy() {
        stopCall();
        super.onDestroy();
    }

    public void onClick(View v) {
        if (engine.isRunning()) {
            stopCall();
        } else {
            startCall();
        }
    }

    private void startCall() {
        String ip = ipEdit.getText().toString().trim();
        if (!isValidIpv4(ip)) {
            Toast.makeText(this, R.string.msg_bad_ip, Toast.LENGTH_SHORT).show();
            return;
        }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_IP, ip).commit();

        try {
            engine.start(ip);
        } catch (Exception e) {
            Toast.makeText(this, getString(R.string.msg_start_failed) + ": " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
            return;
        }

        if (wifi != null) {
            wifiLock = wifi.createWifiLock(WifiManager.WIFI_MODE_FULL, "wifivoice");
            wifiLock.acquire();
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        ipEdit.setEnabled(false);
        callButton.setText(R.string.btn_hangup);
    }

    private void stopCall() {
        engine.stop();
        if (wifiLock != null && wifiLock.isHeld()) {
            wifiLock.release();
        }
        wifiLock = null;
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        ipEdit.setEnabled(true);
        callButton.setText(R.string.btn_call);
    }

    /** 自分のIPアドレスをタイトルバーに表示 (UIはEditTextとButtonのみのため) */
    private void showOwnIp() {
        String text = getString(R.string.title_no_wifi);
        if (wifi != null && wifi.getConnectionInfo() != null) {
            int ip = wifi.getConnectionInfo().getIpAddress();
            if (ip != 0) {
                text = getString(R.string.title_my_ip) + " "
                        + (ip & 0xff) + "." + ((ip >> 8) & 0xff) + "."
                        + ((ip >> 16) & 0xff) + "." + ((ip >> 24) & 0xff);
            }
        }
        setTitle(text);
    }

    private static boolean isValidIpv4(String s) {
        Matcher m = IPV4.matcher(s);
        if (!m.matches()) {
            return false;
        }
        for (int i = 1; i <= 4; i++) {
            if (Integer.parseInt(m.group(i)) > 255) {
                return false;
            }
        }
        return true;
    }
}
