package com.example.wifivoice;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.media.AudioManager;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.SystemClock;
import android.util.TypedValue;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** 電話風UI。発信ダイヤル / 発信中 / 着信 / 通話中 を1画面で切り替える。 */
public class MainActivity extends Activity implements CallService.Listener {

    private static final String PREFS = "wifivoice";
    private static final String KEY_IP = "peer_ip";
    private static final int MAX_LEN = 15;
    private static final String DEL = "削除";
    private static final Pattern IPV4 =
            Pattern.compile("^(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})$");

    private TextView tvStatus;
    private TextView tvNumber;
    private View panelDial;
    private View panelCall;
    private Button btnAccept;
    private Button btnHangUp;

    private final StringBuilder dial = new StringBuilder();
    private final Handler handler = new Handler();
    private CallService service;
    private boolean bound;

    private final Runnable ticker = new Runnable() {
        public void run() {
            render();
            handler.postDelayed(this, 1000);
        }
    };

    private final ServiceConnection connection = new ServiceConnection() {
        public void onServiceConnected(ComponentName name, IBinder binder) {
            service = ((CallService.LocalBinder) binder).getService();
            service.setListener(MainActivity.this);
            render();
        }

        public void onServiceDisconnected(ComponentName name) {
            service = null;
            render();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 着信時にロック画面の上に出し、画面を点灯する
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        setContentView(R.layout.main);
        setVolumeControlStream(AudioManager.STREAM_VOICE_CALL);

        tvStatus = (TextView) findViewById(R.id.tv_status);
        tvNumber = (TextView) findViewById(R.id.tv_number);
        panelDial = findViewById(R.id.panel_dial);
        panelCall = findViewById(R.id.panel_call);
        btnAccept = (Button) findViewById(R.id.btn_accept);
        btnHangUp = (Button) findViewById(R.id.btn_hangup);

        buildKeypad();

        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String last = prefs.getString(KEY_IP, "");
        dial.append(last.length() > 0 ? last : ipPrefix());

        // 待受サービスを起動 (アプリを閉じても着信を受けられる)
        startService(new Intent(this, CallService.class));
    }

    @Override
    protected void onStart() {
        super.onStart();
        bound = bindService(new Intent(this, CallService.class), connection, 0);
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(ticker);
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(ticker);
        super.onPause();
    }

    @Override
    protected void onStop() {
        if (service != null) {
            service.setListener(null);
            service = null;
        }
        if (bound) {
            unbindService(connection);
            bound = false;
        }
        super.onStop();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, 1, 0, "待受を終了");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == 1) {
            stopService(new Intent(this, CallService.class));
            Toast.makeText(this, "待受を終了しました", Toast.LENGTH_SHORT).show();
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // --- Listener ---
    public void onStateChanged() {
        render();
    }

    // --- ボタン (layoutのandroid:onClick) ---
    public void onDial(View v) {
        String ip = dial.toString().trim();
        if (!isValidIpv4(ip)) {
            Toast.makeText(this, "IPアドレスの形式が正しくありません", Toast.LENGTH_SHORT).show();
            return;
        }
        if (service == null) {
            Toast.makeText(this, "準備中です。もう一度押してください", Toast.LENGTH_SHORT).show();
            return;
        }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_IP, ip).commit();
        service.call(ip);
    }

    public void onAccept(View v) {
        if (service != null) {
            service.accept();
        }
    }

    public void onHangUp(View v) {
        if (service != null) {
            service.hangUp();
        }
    }

    // --- 描画 ---
    private void render() {
        int state = service == null ? CallService.IDLE : service.getState();

        if (state == CallService.IDLE) {
            panelDial.setVisibility(View.VISIBLE);
            panelCall.setVisibility(View.GONE);
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            String ip = ownIp();
            tvStatus.setText(ip == null ? "Wi-Fi未接続" : "待受中   自分のIP " + ip);
            if (dial.length() == 0) {
                tvNumber.setText("IPアドレスを入力");
                tvNumber.setTextColor(0xFF6B7785);
            } else {
                tvNumber.setText(dial.toString());
                tvNumber.setTextColor(Color.WHITE);
            }
            return;
        }

        panelDial.setVisibility(View.GONE);
        panelCall.setVisibility(View.VISIBLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        tvNumber.setText(service.getPeerAddress());
        tvNumber.setTextColor(Color.WHITE);

        if (state == CallService.CALLING) {
            btnAccept.setVisibility(View.GONE);
            btnHangUp.setText("キャンセル");
            tvStatus.setText(service.isRemoteRinging() ? "呼び出し中…" : "発信中…");
        } else if (state == CallService.RINGING) {
            btnAccept.setVisibility(View.VISIBLE);
            btnHangUp.setText("拒否");
            tvStatus.setText("着信");
        } else {
            btnAccept.setVisibility(View.GONE);
            btnHangUp.setText("切断");
            long sec = (SystemClock.elapsedRealtime() - service.getConnectedAt()) / 1000;
            if (sec < 0) {
                sec = 0;
            }
            tvStatus.setText("通話中   " + two(sec / 60) + ":" + two(sec % 60));
        }
    }

    private static String two(long n) {
        return n < 10 ? "0" + n : String.valueOf(n);
    }

    // --- キーパッド ---
    private void buildKeypad() {
        LinearLayout keypad = (LinearLayout) findViewById(R.id.keypad);
        String[][] rows = {
                { "1", "2", "3" },
                { "4", "5", "6" },
                { "7", "8", "9" },
                { ".", "0", DEL } };
        int m = dp(4);
        for (int r = 0; r < rows.length; r++) {
            LinearLayout line = new LinearLayout(this);
            line.setOrientation(LinearLayout.HORIZONTAL);
            keypad.addView(line, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
            for (int c = 0; c < rows[r].length; c++) {
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        0, LinearLayout.LayoutParams.MATCH_PARENT, 1f);
                lp.setMargins(m, m, m, m);
                line.addView(makeKey(rows[r][c]), lp);
            }
        }
    }

    private Button makeKey(final String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, DEL.equals(label) ? 18 : 26);
        b.setTextColor(Color.WHITE);
        b.setBackgroundResource(R.drawable.bg_key);
        b.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (DEL.equals(label)) {
                    if (dial.length() > 0) {
                        dial.deleteCharAt(dial.length() - 1);
                    }
                } else if (dial.length() < MAX_LEN) {
                    dial.append(label);
                }
                render();
            }
        });
        if (DEL.equals(label)) {
            b.setOnLongClickListener(new View.OnLongClickListener() {
                public boolean onLongClick(View v) {
                    dial.setLength(0);
                    render();
                    return true;
                }
            });
        }
        return b;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    // --- IP関連 ---
    private String ownIp() {
        WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        if (wm == null || wm.getConnectionInfo() == null) {
            return null;
        }
        int ip = wm.getConnectionInfo().getIpAddress();
        if (ip == 0) {
            return null;
        }
        return (ip & 0xff) + "." + ((ip >> 8) & 0xff) + "."
                + ((ip >> 16) & 0xff) + "." + ((ip >> 24) & 0xff);
    }

    /** 初回の入力補助: 自分のIPの上位3桁 (例 192.168.1.) */
    private String ipPrefix() {
        String ip = ownIp();
        if (ip == null) {
            return "192.168.";
        }
        return ip.substring(0, ip.lastIndexOf('.') + 1);
    }

    private static boolean isValidIpv4(String s) {
        Matcher m = IPV4.matcher(s);
        if (!m.matches()) {
            return false;
        }
        for (int i = 1; i <= 4; i++) {
            if (Integer.parseInt(m.group(i)) > 255) {
                return false;
            }
        }
        return true;
    }
}
