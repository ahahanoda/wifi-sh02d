package com.example.wifivoice;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.media.AudioManager;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.SystemClock;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** 電話風UI。発信ダイヤル / 発信中 / 着信 / 通話中 を1画面で切り替える。 */
public class MainActivity extends Activity implements CallService.Listener {

    private static final String PREFS = "wifivoice";
    private static final String KEY_IP = "peer_ip";
    private static final int MAX_LEN = 15;
    private static final int REQ_CONTACT = 1;
    private static final String DEL = "削除";
    private static final Pattern IPV4 =
            Pattern.compile("^(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})$");

    private TextView tvStatus;
    private TextView tvNumber;
    private View panelDial;
    private View panelCall;
    private Button btnAccept;
    private Button btnHangUp;
    private Button btnSpeaker;

    private final StringBuilder dial = new StringBuilder();
    private final Handler handler = new Handler();
    private CallService service;
    private boolean bound;
    private int volumeStream = -1;
    private boolean keyTest;
    private String keyTestText = "";
    private boolean longHandled;

    private final Runnable ticker = new Runnable() {
        public void run() {
            render();
            handler.postDelayed(this, 1000);
        }
    };

    private final ServiceConnection connection = new ServiceConnection() {
        public void onServiceConnected(ComponentName name, IBinder binder) {
            service = ((CallService.LocalBinder) binder).getService();
            service.setListener(MainActivity.this);
            render();
        }

        public void onServiceDisconnected(ComponentName name) {
            service = null;
            render();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 着信時にロック画面の上に出し、画面を点灯する
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        setContentView(R.layout.main);

        tvStatus = (TextView) findViewById(R.id.tv_status);
        tvNumber = (TextView) findViewById(R.id.tv_number);
        panelDial = findViewById(R.id.panel_dial);
        panelCall = findViewById(R.id.panel_call);
        btnAccept = (Button) findViewById(R.id.btn_accept);
        btnHangUp = (Button) findViewById(R.id.btn_hangup);
        btnSpeaker = (Button) findViewById(R.id.btn_speaker);

        buildKeypad();

        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String last = prefs.getString(KEY_IP, "");
        dial.append(last.length() > 0 ? last : ipPrefix());

        // 待受サービスを起動 (アプリを閉じても着信を受けられる)
        startService(new Intent(this, CallService.class));
    }

    @Override
    protected void onStart() {
        super.onStart();
        bound = bindService(new Intent(this, CallService.class), connection, 0);
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(ticker);
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(ticker);
        super.onPause();
    }

    @Override
    protected void onStop() {
        if (service != null) {
            service.setListener(null);
            service = null;
        }
        if (bound) {
            unbindService(connection);
            bound = false;
        }
        super.onStop();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_CONTACT && resultCode == RESULT_OK && data != null) {
            String ip = data.getStringExtra(ContactsActivity.EXTRA_IP);
            if (ip != null) {
                dial.setLength(0);
                dial.append(ip);
                render();
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, 2, 0, "キーテスト");
        menu.add(0, 1, 1, "待受を終了");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == 2) {
            keyTest = true;
            keyTestText = "キーテスト中\n何かキーを押してください\n(戻るキーで終了)";
            render();
            return true;
        }
        if (item.getItemId() == 1) {
            stopService(new Intent(this, CallService.class));
            Toast.makeText(this, "待受を終了しました", Toast.LENGTH_SHORT).show();
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // --- ハードウェアキー ---
    @Override
    public boolean dispatchKeyEvent(KeyEvent ev) {
        int code = ev.getKeyCode();
        boolean down = ev.getAction() == KeyEvent.ACTION_DOWN;

        if (keyTest) {
            if (code == KeyEvent.KEYCODE_BACK) {
                if (!down) {
                    keyTest = false;
                    render();
                }
                return true;
            }
            if (code == KeyEvent.KEYCODE_MENU) {
                return super.dispatchKeyEvent(ev);
            }
            if (down) {
                keyTestText = "keyCode=" + code + "\nscanCode=" + ev.getScanCode()
                        + "  meta=" + ev.getMetaState()
                        + "\nunicode=" + ev.getUnicodeChar()
                        + "  repeat=" + ev.getRepeatCount()
                        + "\n" + ev;
                render();
            }
            return true;
        }

        if (!down) {
            if (code == KeyEvent.KEYCODE_DEL) {
                longHandled = false;
            }
            // 押下時に処理したキーは、離した時のイベントも他へ渡さない
            return isHandledKey(code) || super.dispatchKeyEvent(ev);
        }

        int state = service == null ? CallService.IDLE : service.getState();
        int rc = ev.getRepeatCount();

        // 通話の終了系キー (終話キーはOSが先に処理する機種が多い)
        if (code == KeyEvent.KEYCODE_ENDCALL) {
            if (rc == 0 && state != CallService.IDLE) {
                onHangUp(null);
            }
            return state != CallService.IDLE;
        }

        // 着信中の音量キー: まず着信音を止める (通話は受けない)
        if ((code == KeyEvent.KEYCODE_VOLUME_UP || code == KeyEvent.KEYCODE_VOLUME_DOWN)
                && state == CallService.RINGING && service != null) {
            service.silenceRinger();
            return true;
        }

        // 発話キー / 決定キー
        if (code == KeyEvent.KEYCODE_CALL || code == KeyEvent.KEYCODE_ENTER
                || code == KeyEvent.KEYCODE_DPAD_CENTER) {
            if (rc == 0) {
                if (state == CallService.IDLE) {
                    onDial(null);
                } else if (state == CallService.RINGING) {
                    onAccept(null);
                } else if (state == CallService.IN_CALL) {
                    onSpeaker(null);
                }
            }
            return true;
        }

        // 削除 / クリア
        if (code == KeyEvent.KEYCODE_DEL || code == KeyEvent.KEYCODE_CLEAR) {
            if (state == CallService.IDLE) {
                if (code == KeyEvent.KEYCODE_DEL && ev.isLongPress()) {
                    if (!longHandled) {
                        longHandled = true;
                        dial.setLength(0);
                        render();
                    }
                } else if (!longHandled && dial.length() > 0) {
                    dial.deleteCharAt(dial.length() - 1);
                    render();
                }
            } else if (rc == 0) {
                onHangUp(null);
            }
            return true;
        }

        if (state == CallService.IDLE) {
            // 数字キー・記号
            char ch = 0;
            if (code >= KeyEvent.KEYCODE_0 && code <= KeyEvent.KEYCODE_9) {
                ch = (char) ('0' + (code - KeyEvent.KEYCODE_0));
            } else if (code == KeyEvent.KEYCODE_STAR || code == KeyEvent.KEYCODE_POUND
                    || code == KeyEvent.KEYCODE_PERIOD) {
                ch = '.';
            } else {
                int u = ev.getUnicodeChar();
                if (u >= '0' && u <= '9') {
                    ch = (char) u;
                } else if (u == '.' || u == '*' || u == '#') {
                    ch = '.';
                }
            }
            if (ch != 0) {
                if (rc == 0 && dial.length() < MAX_LEN) {
                    dial.append(ch);
                    render();
                }
                return true;
            }
            switch (code) {
                case KeyEvent.KEYCODE_DPAD_LEFT:
                    if (dial.length() > 0) {
                        dial.deleteCharAt(dial.length() - 1);
                        render();
                    }
                    return true;
                case KeyEvent.KEYCODE_DPAD_UP:
                    if (rc == 0) {
                        pickContact(-1);
                    }
                    return true;
                case KeyEvent.KEYCODE_DPAD_DOWN:
                    if (rc == 0) {
                        pickContact(1);
                    }
                    return true;
                case KeyEvent.KEYCODE_DPAD_RIGHT:
                    return true;
                case KeyEvent.KEYCODE_SEARCH:
                    if (rc == 0) {
                        onContacts(null);
                    }
                    return true;
                default:
                    break;
            }
        } else if (state == CallService.CALLING || state == CallService.RINGING) {
            // 発信中・着信中は戻るキーでもキャンセル/拒否
            if (code == KeyEvent.KEYCODE_BACK) {
                if (rc == 0) {
                    onHangUp(null);
                }
                return true;
            }
        }
        return super.dispatchKeyEvent(ev);
    }

    /** 離した時に他へ渡さないキー (押下時に処理したもの) */
    private boolean isHandledKey(int code) {
        switch (code) {
            case KeyEvent.KEYCODE_CALL:
            case KeyEvent.KEYCODE_ENDCALL:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_DPAD_LEFT:
            case KeyEvent.KEYCODE_DPAD_RIGHT:
            case KeyEvent.KEYCODE_DPAD_UP:
            case KeyEvent.KEYCODE_DPAD_DOWN:
            case KeyEvent.KEYCODE_DEL:
            case KeyEvent.KEYCODE_CLEAR:
            case KeyEvent.KEYCODE_STAR:
            case KeyEvent.KEYCODE_POUND:
            case KeyEvent.KEYCODE_PERIOD:
            case KeyEvent.KEYCODE_SEARCH:
                return true;
            default:
                return code >= KeyEvent.KEYCODE_0 && code <= KeyEvent.KEYCODE_9;
        }
    }

    /** 連絡先を上下で順に切り替えて、入力欄に入れる */
    private void pickContact(int dir) {
        java.util.List<Contacts.Item> list = Contacts.load(this);
        if (list.size() == 0) {
            Toast.makeText(this, "連絡先が登録されていません", Toast.LENGTH_SHORT).show();
            return;
        }
        int idx = -1;
        String cur = dial.toString().trim();
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).ip.equals(cur)) {
                idx = i;
                break;
            }
        }
        if (idx < 0) {
            idx = dir > 0 ? 0 : list.size() - 1;
        } else {
            idx = (idx + dir + list.size()) % list.size();
        }
        dial.setLength(0);
        dial.append(list.get(idx).ip);
        render();
    }

    // --- Listener ---
    public void onStateChanged() {
        render();
    }

    // --- ボタン (layoutのandroid:onClick) ---
    public void onDial(View v) {
        String ip = dial.toString().trim();
        if (!isValidIpv4(ip)) {
            Toast.makeText(this, "IPアドレスの形式が正しくありません", Toast.LENGTH_SHORT).show();
            return;
        }
        if (service == null) {
            Toast.makeText(this, "準備中です。もう一度押してください", Toast.LENGTH_SHORT).show();
            return;
        }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_IP, ip).commit();
        service.call(ip);
    }

    public void onAccept(View v) {
        if (service != null) {
            service.accept();
        }
    }

    public void onHangUp(View v) {
        if (service != null) {
            service.hangUp();
        }
    }

    public void onSpeaker(View v) {
        if (service != null) {
            service.setSpeaker(!service.isSpeakerOn());
        }
    }

    public void onContacts(View v) {
        startActivityForResult(new Intent(this, ContactsActivity.class), REQ_CONTACT);
    }

    /** 入力中のIPを連絡先に登録 */
    public void onSaveContact(View v) {
        final String ip = dial.toString().trim();
        if (!isValidIpv4(ip)) {
            Toast.makeText(this, "IPアドレスの形式が正しくありません", Toast.LENGTH_SHORT).show();
            return;
        }
        final EditText nameEdit = new EditText(this);
        nameEdit.setSingleLine(true);
        nameEdit.setHint("名前");
        String existing = Contacts.nameFor(this, ip);
        if (existing != null) {
            nameEdit.setText(existing);
        }
        new AlertDialog.Builder(this)
                .setTitle("連絡先に登録 (" + ip + ")")
                .setView(nameEdit)
                .setPositiveButton("保存", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        String name = nameEdit.getText().toString().trim();
                        if (name.length() == 0) {
                            Toast.makeText(MainActivity.this, "名前を入力してください",
                                    Toast.LENGTH_SHORT).show();
                            return;
                        }
                        Contacts.save(MainActivity.this, name, ip);
                        Toast.makeText(MainActivity.this, "登録しました", Toast.LENGTH_SHORT).show();
                        render();
                    }
                })
                .setNegativeButton("キャンセル", null)
                .show();
    }

    // --- 描画 ---
    private void render() {
        if (keyTest) {
            tvStatus.setText("キーテスト");
            tvNumber.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
            tvNumber.setTextColor(Color.WHITE);
            tvNumber.setMaxLines(9);
            tvNumber.setText(keyTestText);
            return;
        }
        tvNumber.setMaxLines(2);
        int state = service == null ? CallService.IDLE : service.getState();

        if (state == CallService.IDLE) {
            panelDial.setVisibility(View.VISIBLE);
            panelCall.setVisibility(View.GONE);
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            setVolumeStream(AudioManager.STREAM_VOICE_CALL);
            String ip = ownIp();
            tvStatus.setText(ip == null ? "Wi-Fi未接続" : "待受中   自分のIP " + ip);
            if (dial.length() == 0) {
                tvNumber.setTextSize(TypedValue.COMPLEX_UNIT_SP, 34);
                tvNumber.setText("IPアドレスを入力");
                tvNumber.setTextColor(0xFF6B7785);
            } else {
                showNumber(dial.toString());
            }
            return;
        }

        panelDial.setVisibility(View.GONE);
        panelCall.setVisibility(View.VISIBLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        showNumber(service.getPeerAddress());

        if (state == CallService.CALLING) {
            btnAccept.setVisibility(View.GONE);
            btnSpeaker.setVisibility(View.GONE);
            btnHangUp.setText("キャンセル");
            tvStatus.setText(service.isRemoteRinging() ? "呼び出し中…" : "発信中…");
        } else if (state == CallService.RINGING) {
            btnAccept.setVisibility(View.VISIBLE);
            btnSpeaker.setVisibility(View.GONE);
            btnHangUp.setText("拒否");
            tvStatus.setText("着信");
        } else {
            btnAccept.setVisibility(View.GONE);
            btnSpeaker.setVisibility(View.VISIBLE);
            boolean on = service.isSpeakerOn();
            btnSpeaker.setText(on ? "スピーカー: オン" : "スピーカー: オフ");
            btnSpeaker.setBackgroundResource(on ? R.drawable.bg_green : R.drawable.bg_key);
            setVolumeStream(on ? AudioManager.STREAM_MUSIC : AudioManager.STREAM_VOICE_CALL);
            btnHangUp.setText("切断");
            long sec = (SystemClock.elapsedRealtime() - service.getConnectedAt()) / 1000;
            if (sec < 0) {
                sec = 0;
            }
            tvStatus.setText("通話中   " + two(sec / 60) + ":" + two(sec % 60));
        }
    }

    /** 連絡先に登録済みなら「名前 + IP」、なければIPだけ表示 */
    private void showNumber(String ip) {
        String name = Contacts.nameFor(this, ip);
        tvNumber.setTextColor(Color.WHITE);
        if (name != null) {
            tvNumber.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26);
            tvNumber.setText(name + "\n" + ip);
        } else {
            tvNumber.setTextSize(TypedValue.COMPLEX_UNIT_SP, 34);
            tvNumber.setText(ip);
        }
    }

    /** 音量キーが効くストリームを、現在の音の出し先に合わせる */
    private void setVolumeStream(int stream) {
        if (volumeStream != stream) {
            volumeStream = stream;
            setVolumeControlStream(stream);
        }
    }

    private static String two(long n) {
        return n < 10 ? "0" + n : String.valueOf(n);
    }

    // --- キーパッド ---
    private void buildKeypad() {
        LinearLayout keypad = (LinearLayout) findViewById(R.id.keypad);
        String[][] rows = {
                { "1", "2", "3" },
                { "4", "5", "6" },
                { "7", "8", "9" },
                { ".", "0", DEL } };
        int m = dp(4);
        for (int r = 0; r < rows.length; r++) {
            LinearLayout line = new LinearLayout(this);
            line.setOrientation(LinearLayout.HORIZONTAL);
            keypad.addView(line, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
            for (int c = 0; c < rows[r].length; c++) {
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        0, LinearLayout.LayoutParams.MATCH_PARENT, 1f);
                lp.setMargins(m, m, m, m);
                line.addView(makeKey(rows[r][c]), lp);
            }
        }
    }

    private Button makeKey(final String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, DEL.equals(label) ? 18 : 26);
        b.setTextColor(Color.WHITE);
        b.setBackgroundResource(R.drawable.bg_key);
        b.setFocusable(false);
        b.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (DEL.equals(label)) {
                    if (dial.length() > 0) {
                        dial.deleteCharAt(dial.length() - 1);
                    }
                } else if (dial.length() < MAX_LEN) {
                    dial.append(label);
                }
                render();
            }
        });
        if (DEL.equals(label)) {
            b.setOnLongClickListener(new View.OnLongClickListener() {
                public boolean onLongClick(View v) {
                    dial.setLength(0);
                    render();
                    return true;
                }
            });
        }
        return b;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    // --- IP関連 ---
    private String ownIp() {
        WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        if (wm == null || wm.getConnectionInfo() == null) {
            return null;
        }
        int ip = wm.getConnectionInfo().getIpAddress();
        if (ip == 0) {
            return null;
        }
        return (ip & 0xff) + "." + ((ip >> 8) & 0xff) + "."
                + ((ip >> 16) & 0xff) + "." + ((ip >> 24) & 0xff);
    }

    /** 初回の入力補助: 自分のIPの上位3桁 (例 192.168.1.) */
    private String ipPrefix() {
        String ip = ownIp();
        if (ip == null) {
            return "192.168.";
        }
        return ip.substring(0, ip.lastIndexOf('.') + 1);
    }

    public static boolean isValidIpv4(String s) {
        Matcher m = IPV4.matcher(s);
        if (!m.matches()) {
            return false;
        }
        for (int i = 1; i <= 4; i++) {
            if (Integer.parseInt(m.group(i)) > 255) {
                return false;
            }
        }
        return true;
    }
}
