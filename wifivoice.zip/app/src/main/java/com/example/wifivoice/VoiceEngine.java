package com.example.wifivoice;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketTimeoutException;

import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.os.Process;

/**
 * UDPで生PCM音声を相手と直接送り合う最小エンジン (Java 6/7互換)。
 * 8kHz / モノラル / 16bit。20msごと(160サンプル=320バイト)に1パケット。
 * SIP(android.net.sip)は使わない。
 */
public class VoiceEngine {

    public interface ErrorListener {
        /** バックグラウンドスレッドから呼ばれる */
        void onError(String message);
    }

    public static final int PORT = 50005;
    public static final int SAMPLE_RATE = 8000;
    /** 20ms分: 8000 * 0.02 * 2byte */
    public static final int FRAME_BYTES = 320;

    private final ErrorListener listener;

    private volatile boolean running;
    private DatagramSocket socket;
    private AudioRecord recorder;
    private AudioTrack track;
    private Thread sendThread;
    private Thread recvThread;
    private InetAddress peer;

    public VoiceEngine(ErrorListener listener) {
        this.listener = listener;
    }

    public boolean isRunning() {
        return running;
    }

    public synchronized void start(String peerIp) throws Exception {
        if (running) {
            return;
        }
        try {
            // 数値のIPアドレスのみ受け付ける(呼び出し側で検証済み)ので名前解決は発生しない
            peer = InetAddress.getByName(peerIp);

            socket = new DatagramSocket(null);
            socket.setReuseAddress(true);
            socket.bind(new InetSocketAddress(PORT));
            socket.setSoTimeout(500);

            // --- 録音 (必要最小限のバッファ) ---
            int recMin = AudioRecord.getMinBufferSize(SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            if (recMin <= 0) {
                throw new Exception("録音バッファサイズを取得できません (" + recMin + ")");
            }
            int recBuf = Math.max(recMin, FRAME_BYTES * 2);
            recorder = createRecorder(MediaRecorder.AudioSource.MIC, recBuf);
            if (recorder == null) {
                recorder = createRecorder(MediaRecorder.AudioSource.VOICE_COMMUNICATION, recBuf);
            }
            if (recorder == null) {
                throw new Exception("マイクを初期化できません (他のアプリが使用中?)");
            }

            // --- 再生 ---
            int trMin = AudioTrack.getMinBufferSize(SAMPLE_RATE,
                    AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
            if (trMin <= 0) {
                throw new Exception("再生バッファサイズを取得できません (" + trMin + ")");
            }
            int trBuf = Math.max(trMin, FRAME_BYTES * 4);
            track = new AudioTrack(AudioManager.STREAM_VOICE_CALL, SAMPLE_RATE,
                    AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    trBuf, AudioTrack.MODE_STREAM);
            if (track.getState() != AudioTrack.STATE_INITIALIZED) {
                throw new Exception("スピーカー出力を初期化できません");
            }
        } catch (Exception e) {
            cleanup();
            throw e;
        }

        running = true;

        sendThread = new Thread(new Runnable() {
            public void run() {
                sendLoop();
            }
        }, "voice-send");
        recvThread = new Thread(new Runnable() {
            public void run() {
                recvLoop();
            }
        }, "voice-recv");
        sendThread.start();
        recvThread.start();
    }

    public synchronized void stop() {
        running = false;
        // receive()のブロックを解除
        if (socket != null) {
            socket.close();
        }
        join(sendThread);
        join(recvThread);
        sendThread = null;
        recvThread = null;
        cleanup();
    }

    private static void join(Thread t) {
        if (t == null) {
            return;
        }
        try {
            t.join(1500);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private AudioRecord createRecorder(int source, int bufSize) {
        try {
            AudioRecord r = new AudioRecord(source, SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufSize);
            if (r.getState() == AudioRecord.STATE_INITIALIZED) {
                return r;
            }
            r.release();
        } catch (Exception e) {
            // 次の候補へ
        }
        return null;
    }

    private void cleanup() {
        if (recorder != null) {
            try {
                if (recorder.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) {
                    recorder.stop();
                }
            } catch (Exception e) {
                // ignore
            }
            recorder.release();
            recorder = null;
        }
        if (track != null) {
            try {
                track.stop();
            } catch (Exception e) {
                // ignore
            }
            track.release();
            track = null;
        }
        if (socket != null) {
            socket.close();
            socket = null;
        }
    }

    private void fail(String message) {
        if (running && listener != null) {
            listener.onError(message);
        }
    }

    /** マイク → UDP送信 */
    private void sendLoop() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO);
        final AudioRecord rec = recorder;
        final DatagramSocket sock = socket;
        byte[] buf = new byte[FRAME_BYTES];
        DatagramPacket packet = new DatagramPacket(buf, buf.length, peer, PORT);
        try {
            rec.startRecording();
            while (running) {
                int filled = 0;
                while (running && filled < FRAME_BYTES) {
                    int n = rec.read(buf, filled, FRAME_BYTES - filled);
                    if (n < 0) {
                        fail("マイク読み取りエラー (" + n + ")");
                        return;
                    }
                    filled += n;
                }
                if (!running) {
                    break;
                }
                packet.setLength(FRAME_BYTES);
                sock.send(packet);
            }
        } catch (IOException e) {
            fail("送信エラー: " + e.getMessage());
        } catch (RuntimeException e) {
            fail("送信スレッドエラー: " + e);
        }
    }

    /** UDP受信 → スピーカー */
    private void recvLoop() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO);
        final AudioTrack tr = track;
        final DatagramSocket sock = socket;
        byte[] buf = new byte[1024];
        DatagramPacket packet = new DatagramPacket(buf, buf.length);
        try {
            tr.play();
            while (running) {
                packet.setLength(buf.length);
                try {
                    sock.receive(packet);
                } catch (SocketTimeoutException e) {
                    continue;
                }
                // 相手以外からのパケットは無視
                if (!peer.equals(packet.getAddress())) {
                    continue;
                }
                int len = packet.getLength() & ~1; // 16bitなので偶数バイトに
                if (len > 0) {
                    tr.write(buf, 0, len);
                }
            }
        } catch (IOException e) {
            // stop()でsocketを閉じた場合は正常終了
            fail("受信エラー: " + e.getMessage());
        } catch (RuntimeException e) {
            fail("受信スレッドエラー: " + e);
        }
    }
}
